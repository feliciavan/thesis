document.addEventListener('DOMContentLoaded', () => {

  document.querySelector('.logout').onclick = logout;

});

function logout() {
  alert('You will log out.');
}
